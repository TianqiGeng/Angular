import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { LoginUser } from './login/loginuser';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  public authURL = 'http://localhost:3000/login';
  public isAuthenticatedURL = 'http://localhost:3000/660/users';

  constructor(private httpClient: HttpClient) {

  }

  authenticateUser(data) {
  }

  setBearerToken(token) {
    localStorage.setItem('bearertoken', token);
  }

  getBearerToken() {
    return localStorage.getItem('bearertoken');
  }

  isUserAuthenticated(token): Observable<Array<LoginUser>> {
  }
}
