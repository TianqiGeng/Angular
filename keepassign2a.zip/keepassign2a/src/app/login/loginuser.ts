export class LoginUser {
    constructor(private email: string, private password: string) {
    }
}